<?php 
class Salesforce {
    
 function __construct()
  {
    $pwd='GlowTouch123';
    $stoken='wULTkec2NO0lzd9dSrvunupw';
    $client_id = '3MVG9pRzvMkjMb6kYhtwvqTMf2YIN03iT3SuaAhXb6V3F.Yw1IScVtoRczssfqP8kHaEld55mNoWEjntTwwW1';
    $client_secret = 'A31ACE5626859F85BC0CAF93CFF9812B5397DECBBA4D64FE1327E153065AE044';
    $getToken = "https://login.salesforce.com/services/oauth2/token";
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_URL, $getToken);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_POSTFIELDS, array(
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'grant_type' => 'password',
        'username'=>'rutuja.bhoyar-a6lr@force.com',
        'password'=>$pwd.$stoken,
        ));
    $result = curl_exec($curl);
    curl_close($curl);
    $result = json_decode($result);
    $this->access_token =  $result->{'access_token'};
    $this->instanceurl =  $result->{'instance_url'};
  }
 

  function getUserbyPhone($phone) {
     $getToken =  $this->instanceurl."/services/data/v34.0/query?q=select+id,UserName,Email,Phone+from+user+where+phone='". $phone . "'";
   
    $curlE = curl_init();

    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$this->access_token
    ));
    
    curl_setopt($curlE, CURLOPT_URL, $getToken);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result_useremail = curl_exec($curlE);
    curl_close($curlE);
    $resEmail = json_decode($result_useremail);
    $resEmail = $resEmail->{'records'};
    return $resEmail;
    }
    
    
    function getCaseReason() {
     $getToken =  $this->instanceurl."/services/data/v58.0/ui-api/object-info/Case/picklist-values/012000000000000AAA/Reason";
   
    $curlE = curl_init();

    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$this->access_token
    ));
    
    curl_setopt($curlE, CURLOPT_URL, $getToken);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result = curl_exec($curlE);
    curl_close($curlE);
    
    return $result;
    }
    
    function getUserDetails($data,$type) {
    if($type == 'name'){
        
    $splitStr = explode(" ",$data);
    if(count($splitStr) > 0)
    {
        $data=implode("+",$splitStr);
    }
    else{
         $data=$searchUser;
    }
    }
    
    $getToken =  $this->instanceurl."/services/data/v34.0/query?q=select+id,UserName,Email,Phone+from+user+where+".$type."='". $data . "'";
    
    $curlE = curl_init();

    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$this->access_token
    ));
    
    curl_setopt($curlE, CURLOPT_URL, $getToken);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result_useremail = curl_exec($curlE);
    curl_close($curlE);
   
    $resEmail = json_decode($result_useremail);
    $resEmail = $resEmail->{'records'};
    return $resEmail;
    }
    
    function getCaseID($casenumber){
      
    $getCaseID = $this->instanceurl."/services/data/v34.0/query?q=select+Id+from+Case+where+CaseNumber='".$casenumber."'";
    $curlE = curl_init();
    
    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token,
         "Content-Type: application/json"
     ));
     
    curl_setopt($curlE, CURLOPT_URL, $getCaseID);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result = curl_exec($curlE);
    curl_close($curlE);
    $result=json_decode($result);
    $result=$result->{'records'};
    return $result[0]->{'Id'};
  }
  
  function updateCase($ticketId,$ticketData,$comment){
    $updateTicket = "https://agility-app-3236.my.salesforce.com/services/data/v58.0/sobjects/Case/".$ticketId;
    $curlE = curl_init();
    
    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token,
         "Content-Type: application/json"
     ));
     //echo $this->access_token;
    //curl_setopt($curlE, CURLOPT_GET, TRUE);
    curl_setopt($curlE, CURLOPT_URL, $updateTicket);
    curl_setopt($curlE, CURLOPT_CUSTOMREQUEST, 'PATCH');
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curlE, CURLOPT_POSTFIELDS,$ticketData);
    
    $result_comment = curl_exec($curlE);
    curl_close($curlE);
    
    
    $updatecomm = "https://agility-app-3236.my.salesforce.com/services/data/v58.0/sobjects/CaseComment";
    $curl = curl_init();
    
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token,
         "Content-Type: application/json"
     ));
     //echo $this->access_token;
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_URL, $updatecomm);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_POSTFIELDS,$comment);
    
    $result_comment = curl_exec($curl);
    curl_close($curl);
    return json_decode($result_comment);
      
  }
  
  function getTicket($ticketId){
     $getTicket = "https://".$this->subdomain."/api/v2/tickets/".$ticketId;
    $curlT = curl_init();
    
    curl_setopt($curlT, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
     
    curl_setopt($curlT, CURLOPT_URL, $getTicket);
    curl_setopt($curlT, CURLOPT_RETURNTRANSFER, TRUE);
    $result_ticket = curl_exec($curlT);
    curl_close($curlT);
    
    return json_decode($result_ticket);
  }
  
  function getComments($ticketId){
      $getComments = "https://".$this->subdomain."/api/v2/tickets/".$ticketId."/comments";
    $curlU = curl_init();
    
    curl_setopt($curlU, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
     
    curl_setopt($curlU, CURLOPT_URL, $getComments);
    curl_setopt($curlU, CURLOPT_RETURNTRANSFER, TRUE);
    $comments = curl_exec($curlU);
    curl_close($curlU);
    $comment = json_decode($comments);
    return json_decode(json_encode($comment), true);
  }
}


?>