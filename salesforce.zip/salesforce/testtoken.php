<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
include('salesforce.php');
$userId='';
$email='';
$role='';
$name='';
$pageurl='';
$errorMsg='';
$searchType='';
$empty='';
 $zendesk = new Salesforce();
 echo $zendesk->getCaseID('00001003');
?>

