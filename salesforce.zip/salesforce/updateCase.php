<?php
include('salesforce.php');
$ticketId='';
$comment='';
$Type='';
$priority='';
$errorMsg='';
$zendesk = new Salesforce();
$caseReasons=$zendesk->getCaseReason();
$caseReasons=json_decode($caseReasons);
$caseReasons=$caseReasons->{'values'};

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
try{
    
$zendesk = new Salesforce();



$ticketId = $_POST['ticketId'];
$body  = $_POST['comment'];
$Type  = $_POST['Type'];
$priority  = $_POST['priority'];
$reason  = $_POST['reason'];

$caseID = $zendesk->getCaseID($ticketId);

    
$myObj = new stdClass();
$myObj->Priority = $priority;
$myObj->Type =  $Type;
$myObj->Reason = $reason;


$myComm = new stdClass();
$myComm->commentBody = $body;
$myComm->ParentId =  $caseID;


$caseData = json_encode($myObj);
$comment = json_encode($myComm );
$resTicket = $zendesk->updateCase($caseID,$caseData,$comment);



}
catch(Exception $e){
    echo 'Message: ' .$e->getMessage();
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Salesforce Application</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zendeskapp.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="header">
  <a href="https://salesforceapptest.com/salesforce" class="header-button">Home</a>
</div>
  
<div class="content" style="max-width:1600px">
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container white margin">
        <div class="action_btn">
            
       <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">   
       <input type="hidden" value="<?php echo $_GET["code"];?>" name="hidden1" required><br>
        <label for="fname">Case Number:</label><br>
        <input type="text" id="fname" name="ticketId" value="" required><br><br>
        <label for="fname">Case Reason:</label><br>
        <select id="reason" name="reason" required >
            <option value="">Select Reason</option>
            <?php 
          
              foreach($caseReasons as $cr){
               echo '<option value="'.$cr->{'label'}.'">'.$cr->{'value'}.'</option>';
              }
                  
           ?>
            <!--<option value="User didn't attend training">User didn't attend training</option>-->
            <!--<option value="Complex functionality">Complex functionality</option>-->
            <!--<option value="Existing problem">Existing problem</option>-->
            <!--<option value="Instructions not clear">Instructions not clear</option>-->
            <!--<option value="New Problem">New Problem</option>-->
            
          </select><br><br>
        <label for="lname">Comment:</label><br>
        <textarea name="comment" required></textarea>
        <!--<input type="text" id="lname" name="comment" value="" required>-->
        <br><br>
        <label for="lname">Select Type:</label><br>
        <select id="Type" name="Type" required >
            <option value="">Select Type</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Electrical">Electrical</option>
            <option value="Electronic">Electronic</option>
            <option value="Structural">Structural</option>
            <option value="Other">Other</option>
          </select><br><br>
        <label for="lname">Select Priority:</label><br>
        <select id="priority" name="priority" required>
            <option value="">Select Priority</option>
            <option value="Low">Low</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
          </select><br><br>
          
        <input type="submit" value="Submit Comment">
		 </form> 
        </div>		
      </div>
    </div>
  </div>

 
</div>

<script>

</script>

</body>
</html>