<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
include('salesforce.php');
$userId='';
$email='';
$role='';
$name='';
$pageurl='';
$errorMsg='';
$searchType='';
$empty='';

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
try{
    
    $zendesk = new Salesforce();
    $searchUser=htmlspecialchars($_POST['searchUser']);
    $searchType=htmlspecialchars($_POST['Type']);
    $resUser = $zendesk->getUserDetails($searchUser,$searchType);
    if(empty($resUser)){
        $errorMsg = 'No data found';
    }

}
catch(Exception $e){
    echo 'Message: ' .$e->getMessage();
}
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Zendesk Application</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zendeskapp.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="header">
    <?php 
    $url1="https://salesforceapptest.com/salesforce/index.php";
    $url2="https://salesforceapptest.com/salesforce/updateCase.php";
    
    ?>
  <a href="<?php echo $url1?>" class="header-button">Home</a>
  <a href="<?php echo $url2?>" class="header-button">Comment</a>
</div>
  
<div class="content" style="max-width:1600px">
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container white margin">
        <div class="action_btn">
            
       <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
           <div class="float-container">

              <div class="float-child1">
                <div class="green">
                    <label for="lname">Search User By:</label><br>
                      <select id="Type" name="Type" class="search" required >
                        <option value="">Select</option>
                        <option value="name">Name</option>
                        <option value="phone">Phone</option>
                        <option value="email">Email</option>
                      </select></div>
              </div>
  
              <div class="float-child2">
                <div class="blue">
                    <label for="lname" >Enter Search Value:</label><br>
            		  <input type="text" value="" name="searchUser"
            		  style="margin-top: 15px;" required>
            		  <button type="submit" class="container-btn white border action_btn" 
            		  style="margin-bottom: 15px;margin-left: 25px;"><b>Pull Customer Info</b></button>
            	</div>
              </div>
  
           </div>
          
          
		 </form> 
        </div>		
      </div>
    </div>
  </div>
  <!-- This section to be shown on click of pull CRM -->
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container grey">
          <h4>Customer Detail</h4>
      </div>
      <?php if($resUser!=''){?>
	  <div>
        <table style="width:100%">
          <tr>
            <th><b>Customer ID</b></th>
            <th>Name</th>
            <th>Email</th>
			<th>Phone</th>
			<th></th>
          </tr>
          <?php 
          
              foreach($resUser as $u){
              $pageurl = "https://agility-app-3236.my.salesforce.com/lightning/r/User/". $u->{'Id'} . "/view";
                  
           ?>
           <tr>
            <td><?php echo $u->{'Id'};?></td>
            <td><?php echo $u->{'Username'};?></td>
            <td><?php echo $u->{'Email'};?></td>
			<td><?php echo $u->{'Phone'};?></td>
			<td><b>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $pageurl?>">Load CRM</a>
			</b>
			    
			    </td>
		
          </tr>  
          <?php }
           ?>
          
        </table>
      </div>
    <?php } ?>
      <?php if($errorMsg){
          echo $errorMsg;
      }?>
    </div>
  </div>
</div>

<script>

</script>

</body>
</html>
