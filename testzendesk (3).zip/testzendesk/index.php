<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
include('zendesk.php');
$userId='';
$email='';
$role='';
$name='';
$pageurl='';
$errorMsg='';
$searchType='';
$empty='';

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
try{
$subdomain='pdi-glowtouch.zendesk.com';
$zendesk = new Zendesk();
    
$searchUser=htmlspecialchars($_POST['searchUser']);
$searchType=htmlspecialchars($_POST['Type']);
if($searchType == 'id'){
    $resUser = $zendesk->getUserbyId($searchUser);
    $userData = $resUser->{'user'};
    $userId =$userData->{'id'};
    $name = $userData->{'name'};
    $email =$userData->{'email'};
    $role = $userData->{'role'};
    $pageurl = "https://".$subdomain."/agent/users/".$userId."/assigned_tickets";
   
    $empty=$userData->{'id'};
}else{
    
    $splitStr = explode(" ",$searchUser);
    if(count($splitStr) > 0)
    {
        $search=implode("+",$splitStr);
    }
    else{
         $search=$searchUser;
    }
    $resUser = $zendesk->searchUser($search);
    $Users = json_decode(json_encode($resUser),true);
    $empty =$Users['users'][0];
}

 $commentUrl = "/testzendesk/updateTicket.php";
if(empty($empty)){
    $errorMsg = 'No data found';
}


}
catch(Exception $e){
    echo 'Message: ' .$e->getMessage();
}
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Zendesk Application</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zendeskapp.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="header">
  <a href="/testzendesk/index.php" class="header-button">Home</a>
  <a href="/testzendesk/updateTicket.php" class="header-button">Comment</a>
</div>
  
<div class="content" style="max-width:1600px">
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container white margin">
        <div class="action_btn">
            
       <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
           <div class="float-container">

              <div class="float-child1">
                <div class="green">
                    <label for="lname">Search User By:</label><br>
                      <select id="Type" name="Type" class="search" required >
                        <option value="">Select</option>
                        <option value="id">ID</option>
                        <option value="Name">Name</option>
                        <option value="phone">Phone</option>
                        <option value="email">Email</option>
                      </select></div>
              </div>
  
              <div class="float-child2">
                <div class="blue">
                    <label for="lname" >Enter Search Value:</label><br>
            		  <input type="text" value="" name="searchUser" required>
            		  <button type="submit" class="container-btn white border action_btn"><b>Pull Customer Info</b></button>
            	</div>
              </div>
  
           </div>
          
          
		 </form> 
        </div>		
      </div>
    </div>
  </div>
  <!-- This section to be shown on click of pull CRM -->
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container grey">
          <h4>Customer Detail</h4>
      </div>
      <?php if(!empty($empty)){?>
	  <div>
        <table style="width:100%">
          <tr>
            <th><b>Customer ID</b></th>
            <th>Name</th>
            <th>Email</th>
			<th>Role</th>
			<th></th>
          </tr>
          <?php if($searchType=='id'){?>
          <tr>
            <td><?php echo $userId;?></td>
            <td><?php echo $name;?></td>
            <td><?php echo $email;?></td>
			<td><?php echo $role;?></td>
			<td><b>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $pageurl?>">Load CRM</a>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $commentUrl?>">Add Comment</a>
			</b>
			    
			    </td>
		
          </tr>  
          <?php } else{
              foreach($Users as $user){
                   foreach($user as $u){
                        $pageurl = "https://".$subdomain."/agent/users/".$u['id']."/assigned_tickets";
          ?>
           <tr>
            <td><?php echo $u['id'];?></td>
            <td><?php echo $u['name'];?></td>
            <td><?php echo $u['email'];?></td>
			<td><?php echo $u['role'];?></td>
			<td><b>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $pageurl?>">Load CRM</a>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $commentUrl?>">Add Comment</a>
			</b>
			    
			    </td>
		
          </tr>  
          <?php }}
          } ?>
          
        </table>
      </div>
      <?php } ?>
      <?php if($errorMsg){
          echo $errorMsg;
      }?>
    </div>
  </div>
</div>

<script>

</script>

</body>
</html>
