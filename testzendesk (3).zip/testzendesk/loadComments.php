<?php
include('zendesk.php');

try{
$zendesk = new Zendesk();
$ticketId= $_GET['ticketID'];
$commentArr=$zendesk->getComments($ticketId);

}
catch(Exception $e){
    echo 'Message: ' .$e->getMessage();
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Zendesk Application</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zendeskapp.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="header">
  <a href="/testzendesk/index.php" class="header-button">Home</a>
  <a href="/testzendesk/updateTicket.php" class="header-button">Comment</a>
</div>
  
<div class="content" style="max-width:1600px">
  
   <div class="row padding">
    <div class="col l8 s12">
        <?php if($errorMsg){
          echo $errorMsg;
      }?>
      <div class="container grey">
          <h4>Comment Details</h4>
      </div>
      <?php if($ticketId != ''){?>
	  <div>
        <table style="width:100%">
          <tr>
            <th><b>Comment ID</b></th>
            <th>Comment</th
          </tr>
          <?php foreach($commentArr['comments'] as $comm){?>
          <tr>
            <td><?php echo $comm['id'];?></td>
            <td><?php echo $comm['body'];?></td>
          </tr>
          <?php } ?>
        </table>
      </div>
      <?php } ?>
      
    </div>
  </div> 
</div>

<script>

</script>

</body>
</html>