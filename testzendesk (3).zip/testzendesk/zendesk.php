<?php 
class Zendesk {
 public $access_token;
 public $subdomain;

  function __construct()
  {
    /*creating token could be done only once and then token could be get stored in session for api calls.Need to test.In that case if token expires will have to revoke token again.*/
    $subdomain='pdi-glowtouch.zendesk.com'; 
    $client_id = 'testzendesk';
    $client_secret = 'bdb7fef6c16e5cff5eb6b8a682df557537b402fbb77701721b6384307b6ac695';
    $username ='majid.k@glowtouch.com';
    $password  = 'Glow*123';
    $getToken = "https://".$subdomain."/oauth/tokens";
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_URL, $getToken);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_POSTFIELDS, array(
        'scope' => 'read write',
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'grant_type' => 'password',
        'username'  => $username,
        'password'  => $password
        ));
    $result = curl_exec($curl);
    curl_close($curl);
    $resArr = json_decode($result);
    $this->access_token = $resArr->{'access_token'};
    $this->subdomain = $subdomain;
  }

  function getUserbyPhone($phone) {
    $getToken = "https://".$this->subdomain."/api/v2/users/search.json?query=".$phone;
    $curlE = curl_init();

    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$this->access_token
    ));
    
    curl_setopt($curlE, CURLOPT_URL, $getToken);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result_useremail = curl_exec($curlE);
    curl_close($curlE);
    $resEmail = json_decode($result_useremail);

    $user_id = $resEmail->{'users'};
    $userId = $user_id[0]->{'id'};
    return $userId;
    }
    
    function searchUser($query) { 
    $getToken = "https://".$this->subdomain."/api/v2/users/search.json?query=".$query;
    
    $curlE = curl_init();

    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$this->access_token
    ));
    
    curl_setopt($curlE, CURLOPT_URL, $getToken);
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    $result_useremail = curl_exec($curlE);
    curl_close($curlE);
    $resEmail = json_decode($result_useremail);
    return $resEmail;
    }
  
  function getUserbyId($userId){
      
    $getUser = "https://".$this->subdomain."/api/v2/users/".$userId;
    $curlU = curl_init();
    
    curl_setopt($curlU, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
    
    curl_setopt($curlU, CURLOPT_URL, $getUser);
    curl_setopt($curlU, CURLOPT_RETURNTRANSFER, TRUE);
    $result_user = curl_exec($curlU);
    curl_close($curlU);
    $resUser = json_decode($result_user);
    return $resUser;
  }
  
  function updateTicket($ticketId,$ticketData){
    $updateTicket = "https://".$this->subdomain."/api/v2/tickets/".$ticketId;
    $curlE = curl_init();
    
    curl_setopt($curlE, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
     
    //curl_setopt($curlE, CURLOPT_GET, TRUE);
    curl_setopt($curlE, CURLOPT_URL, $updateTicket);
    curl_setopt($curlE, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($curlE, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curlE, CURLOPT_POSTFIELDS,http_build_query($ticketData));
    
    $result_comment = curl_exec($curlE);
    curl_close($curlE);
    return json_decode($result_comment);
      
  }
  
  function getTicket($ticketId){
     $getTicket = "https://".$this->subdomain."/api/v2/tickets/".$ticketId;
    $curlT = curl_init();
    
    curl_setopt($curlT, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
     
    curl_setopt($curlT, CURLOPT_URL, $getTicket);
    curl_setopt($curlT, CURLOPT_RETURNTRANSFER, TRUE);
    $result_ticket = curl_exec($curlT);
    curl_close($curlT);
    
    return json_decode($result_ticket);
  }
  
  function getComments($ticketId){
      $getComments = "https://".$this->subdomain."/api/v2/tickets/".$ticketId."/comments";
    $curlU = curl_init();
    
    curl_setopt($curlU, CURLOPT_HTTPHEADER, array(
         "Authorization: Bearer ".$this->access_token
     ));
     
    curl_setopt($curlU, CURLOPT_URL, $getComments);
    curl_setopt($curlU, CURLOPT_RETURNTRANSFER, TRUE);
    $comments = curl_exec($curlU);
    curl_close($curlU);
    $comment = json_decode($comments);
    return json_decode(json_encode($comment), true);
  }
}


?>