<?php
include('zendesk.php');
$ticketId='';
$comment='';
$Type='';
$priority='';
$errorMsg='';

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
try{
    
$zendesk = new Zendesk();


$ticketId = $_POST['ticketId'];
$body  = $_POST['comment'];
$Type  = $_POST['Type'];
$priority  = $_POST['priority'];
$category  = $_POST['category'];
$custom_field_id = '360045027634';
$ticketData = array(
    'ticket' => array
    (
        'comment' => 
            array (
            'body' => $body,
            'public' => true
        ),
       'priority'=> $priority,
       'type' => $Type,
       'custom_fields' => array
       (
           'id'=>$custom_field_id,
           'value'=>$category
       )
    
    )
    
    );

$resTicket = $zendesk->updateTicket($ticketId,$ticketData);

$resT = $zendesk->getTicket($ticketId);

$tPriority = $resT->{'ticket'}->{'priority'};
$tType = $resT->{'ticket'}->{'type'};
$subject = $resT->{'ticket'}->{'subject'};
$category_arr = $resT->{'ticket'}->{'custom_fields'};
$cat_data = $category_arr[2];
$cat_val = ($cat_data->{'value'});


if(empty($resTicket)){
    $errorMsg = $resTicket.'No comment added';
}
else{
    $errorMsg = 'Comment added Sucessfully';

}


$pageurl = "/testzendesk/loadComments.php?ticketID=".$ticketId;

}
catch(Exception $e){
    echo 'Message: ' .$e->getMessage();
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Zendesk Application</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zendeskapp.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="header">
  <a href="/testzendesk/index.php" class="header-button">Home</a>
  <a href="/testzendesk/updateTicket.php" class="header-button">Comment</a>
</div>
  
<div class="content" style="max-width:1600px">
  <div class="row padding">
    <div class="col l8 s12">
      <div class="container white margin">
        <div class="action_btn">
            
       <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">   
        <label for="fname">Ticket Id:</label><br>
        <input type="text" id="fname" name="ticketId" value="" required><br><br>
        <label for="lname">Comment:</label><br>
        <textarea name="comment" required></textarea>
        <!--<input type="text" id="lname" name="comment" value="" required>-->
        <br><br>
        <label for="lname">Select Type:</label><br>
        <select id="Type" name="Type" required >
            <option value="">Select Type</option>
            <option value="Question">Question</option>
            <option value="incident">Incident</option>
            <option value="problem">Problem</option>
            <option value="task">Task</option>
          </select><br><br>
        <label for="lname">Select Priority:</label><br>
        <select id="priority" name="priority" required>
            <option value="">Select Priority</option>
            <option value="low">Low</option>
            <option value="normal">Normal</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select><br><br>
          <label for="lname">Select Category:</label><br>
        <select id="category" name="category" required>
            <option value="">Select Category</option>
            <option value="audio_issue">Audio Issue</option>
            <option value="cancellation_">Cancellation</option>
            <option value="customer_service_">Customer Service</option>
            <option value="hang_up_">Hang Up</option>
            <option value="needs_service">Needs Service</option>
            <option value="no_sale">No Sale</option>
            <option value="payment_issue_">Payment Issue</option>
            <option value="sale">Sale</option>
            <option value="subsequent_payment_">Subsequent Payment</option>
            <option value="test_call">Test Call</option>
            <option value="wrong_number_">Wrong Number</option>
          </select><br><br>
        <input type="submit" value="Update Ticket">
		 </form> 
        </div>		
      </div>
    </div>
  </div>

   <div class="row padding">
    <div class="col l8 s12">
        <?php if($errorMsg){
          echo $errorMsg;
      }?>
      <div class="container grey">
          <h4>Ticket Detail</h4>
      </div>
      <?php if($ticketId != ''){?>
	  <div>
        <table style="width:100%">
          <tr>
            <th><b>Ticket ID</b></th>
            <th>Subject</th>
            <th>Prority</th>
			<th>Type</th>
			<th>Category</th>
			<th></th>
          </tr>
          <tr>
            <td><?php echo $ticketId;?></td>
            <td><?php echo $subject;?></td>
            <td><?php echo $tPriority;?></td>
			<td><?php echo $tType;?></td>
			<td><?php echo $cat_val;?></td>
			<td><b>
			    <a class="container-btn white border action_btn" target="_blank" href="<?php echo $pageurl?>">Load Comments</a>
			</b>
			    
			    </td>
		
          </tr>        
        </table>
      </div>
      <?php } ?>
      
    </div>
  </div> 
</div>

<script>

</script>

</body>
</html>